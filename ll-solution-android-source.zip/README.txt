L&L SOLUTION – ANDROID APP

Dies ist die echte Android-App-Hülle für eure bestehende L&L Solution.
Sie öffnet die aktuelle V6.6-Web-App im eigenen Vollbildfenster, mit eigenem App-Icon und ohne Browserleiste.
Uploads von Bildern/PDFs funktionieren über den Android-Dateiauswahldialog.

APK automatisch bauen:
1. Projekt in ein GitHub-Repository hochladen.
2. GitHub Actions startet automatisch.
3. Unter Actions -> Build Android APK -> Artifacts -> LL-Solution-APK herunterladen.
4. app-debug.apk in LL-Solution.apk umbenennen und auf eure Download-Seite legen.

Für eine langfristige Produktionsversion sollte anschließend eine eigene Release-Signatur/Keystore verwendet werden.
