plugins {
    id("com.android.application")
}

android {
    namespace = "de.llsolution.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "de.llsolution.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 613
        versionName = "6.13"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
}
